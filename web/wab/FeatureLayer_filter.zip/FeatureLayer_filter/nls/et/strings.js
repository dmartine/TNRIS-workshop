define(
   ({
    _widgetLabel: "Kohalik Layer Widget"
  })
);

define(
   ({
    _widgetLabel: "Widget Camada local"
  })
);

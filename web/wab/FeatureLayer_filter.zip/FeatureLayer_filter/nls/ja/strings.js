define(
   ({
    _widgetLabel: "ローカルなレイヤウィジェット"
  })
);

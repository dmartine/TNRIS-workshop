define(
   ({
    _widgetLabel: "Vietinis lygmuo widget"
  })
);

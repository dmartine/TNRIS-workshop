define(
   ({
    _widgetLabel: "지역 계층 위젯"
  })
);

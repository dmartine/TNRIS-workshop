define(
   ({
    _widgetLabel: "Lokale lag Widget"
  })
);

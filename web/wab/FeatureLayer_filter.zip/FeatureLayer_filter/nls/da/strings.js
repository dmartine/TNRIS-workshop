define(
   ({
    _widgetLabel: "Local Layer Widget"
  })
);

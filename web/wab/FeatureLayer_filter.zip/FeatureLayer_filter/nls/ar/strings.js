define(
   ({
    _widgetLabel: "القطعة طبقة المحلية"
  })
);

define(
   ({
    _widgetLabel: "Widget Layer locale"
  })
);

define(
   ({
    _widgetLabel: "Lokale Ebene Widget"
  })
);

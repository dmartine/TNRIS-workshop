define(
   ({
    _widgetLabel: "Lokale Layer Widget"
  })
);

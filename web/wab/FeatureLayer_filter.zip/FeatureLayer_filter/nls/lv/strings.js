define(
   ({
    _widgetLabel: "Vietējā Layer logrīku"
  })
);

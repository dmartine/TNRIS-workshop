define(
   ({
    _widgetLabel: "Lokal Layer Widget"
  })
);

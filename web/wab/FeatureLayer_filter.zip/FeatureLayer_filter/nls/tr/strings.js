define(
   ({
    _widgetLabel: "Yerel Katman Widget"
  })
);

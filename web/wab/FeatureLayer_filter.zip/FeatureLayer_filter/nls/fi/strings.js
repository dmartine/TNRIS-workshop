define(
   ({
    _widgetLabel: "Paikallinen Layer Widget"
  })
);

define(
   ({
    _widgetLabel: "Lokalny Widget Warstwa"
  })
);

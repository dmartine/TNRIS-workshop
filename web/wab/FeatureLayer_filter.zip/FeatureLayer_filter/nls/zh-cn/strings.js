define(
   ({
    _widgetLabel: "當地層的Widget"
  })
);

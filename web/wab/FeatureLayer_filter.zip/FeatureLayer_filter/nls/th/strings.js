define(
   ({
    _widgetLabel: "Widget ชั้นท้องถิ่น"
  })
);

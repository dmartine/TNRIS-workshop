define(
   ({
    _widgetLabel: "Widget livello locale"
  })
);

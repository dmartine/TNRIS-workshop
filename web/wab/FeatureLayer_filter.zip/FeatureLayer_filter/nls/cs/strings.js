define(
   ({
    _widgetLabel: "Místní Widget vrstva"
  })
);

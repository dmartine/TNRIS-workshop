define(
   ({
    _widgetLabel: "Слой местного Виджет"
  })
);

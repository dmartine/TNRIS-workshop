define(
   ({
    _widgetLabel: "Local lớp Widget"
  })
);

define(
   ({
    _widgetLabel: "יישומון Layer המקומי"
  })
);

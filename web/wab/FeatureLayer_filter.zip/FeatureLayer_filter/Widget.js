/*global define, dojo, window, $*/
define([
 'dojo/_base/declare',
 'jimu/BaseWidget',
 'jimu/ConfigManager',
 'jimu/MapManager',
 'esri/urlUtils',
 'dojo/_base/array',
 'dojo/_base/query',
 'dojo/_base/connect',
 'esri/layers/ArcGISDynamicMapServiceLayer',
 'esri/layers/ArcGISTiledMapServiceLayer',
 'esri/layers/FeatureLayer',
 'esri/layers/ImageParameters',
 'esri/dijit/BasemapGallery',
 'esri/dijit/BasemapLayer',
 'esri/dijit/Basemap',
 'esri/basemaps',
 'esri/dijit/PopupTemplate',
 'dojo/_base/html',
 'dojo/on',
 'dojo/dom',
 'dojo/_base/lang',
 'dijit/form/Select'
  ],
  function (
    declare,
    BaseWidget,
    ConfigManager,
    MapManager,
    urlUtils,
    array,
    query,
    connect,
    ArcGISDynamicMapServiceLayer,
    ArcGISTiledMapServiceLayer,
    FeatureLayer,
    ImageParameters,
    BasemapGallery,
    BasemapLayer,
    Basemap,
    esriBasemaps,
    PopupTemplate,
    html,
    on,
    dom,
    lang) {
    var defExp = '',
      
	    inspectionRating = null,
      filterLayer = null;

    var clazz = declare([BaseWidget], {
      baseClass: 'definition_query',

      //this property is set by the framework when widget is loaded.
        name: 'FeatureLayer_filter',
      constructor: function () {
        this._originalWebMap = null;
        defExp = 'RatingScore =\'A\'';
        
      },

      postCreate: function () {
        this.inherited(arguments);
      },

      onClose: function () {
        if (query('.jimu-popup.widget-setting-popup', window.parent.document).length === 0) {
          var _currentExtent = dojo.clone(this.map.extent);
          var _changedData = {
            itemId: this._originalWebMap
          };
          var _newBasemap = connect.subscribe('mapChanged', function (_map) {
            _newBasemap.remove();
            _map.setExtent(_currentExtent);
          });
          MapManager.getInstance().onAppConfigChanged(ConfigManager.getConfig(), 'mapChange', _changedData);
        }
      },

      initSelects: function() {
        //setup change event for selects
        query('select').forEach(lang.hitch(this, function (node) {
          on(node, 'change', lang.hitch(this, function (e) {
            var target = e.target || e.srcElement;
            this.applyFilter(target.value);
          }));
        }));
      },

      applyFilter: function(selValue) {
        switch (selValue) {
        case '0':
          defExp = 'RatingScore =\'A\'';
          break;
        case '1':
          defExp = 'RatingScore =\'B\'';
          break;
        case '2':
          defExp = 'RatingScore =\'C\'';
          break;
        case '6':
          defExp = 'RatingScore =\'D\'';
          break;
        case '7':
          defExp = 'RatingScore=\'F\'';
          break;    
        case 'Clear':
          defExp = '';
          break;
            
        }

        var defArr = [];
        if (defExp !== '') {
          defArr.push(defExp);
        }
            
        filterLayer.setDefinitionExpression(defArr.join(' AND '));
        console.info(defArr.join(' AND '));
      },

      startup: function () {
          
    
        this.initSelects();
		
		    //-----------------------------------------------local Layer--------------------------------------------------------------
        this._originalWebMap = this.map.webMapResponse.itemInfo.item.id;

        if (this.config.useProxy) {
          urlUtils.addProxyRule({
            urlPrefix: this.config.proxyPrefix,
            proxyUrl: this.config.proxyAddress
          });
        }

        inspectionRating = this.config.ratings;
        this.config.layers.layer.forEach(function (layer) {
          var lLayer;
          var lOptions = {};
          if (layer.hasOwnProperty('opacity')) {
            lOptions.opacity = layer.opacity;
          }
          if (layer.hasOwnProperty('visible') && !layer.visible) {
            lOptions.visible = false;
          } else {
            lOptions.visible = true;
          }
          if (layer.name) {
            lOptions.id = layer.name;
          }
          if (layer.type.toUpperCase() === 'DYNAMIC') {
            if (layer.imageformat) {
              var ip = new ImageParameters();
              ip.format = layer.imageformat;
              if (layer.hasOwnProperty('imagedpi')) {
                ip.dpi = layer.imagedpi;
              }
              lOptions.imageParameters = ip;
            }
            lLayer = new ArcGISDynamicMapServiceLayer(layer.url, lOptions);
            if (layer.popup) {
              var finalInfoTemp = {};
              array.forEach(layer.popup.infoTemplates, function (_infoTemp) {
                var popupInfo = {};
                popupInfo.title = _infoTemp.title;
                if (_infoTemp.description) {
                  popupInfo.description = _infoTemp.description;
                } else {
                  popupInfo.description = null;
                }
                if (_infoTemp.fieldInfos) {
                  popupInfo.fieldInfos = _infoTemp.fieldInfos;
                }
                var _popupTemplate1 = new PopupTemplate(popupInfo);
                finalInfoTemp[_infoTemp.layerId] = {
                  infoTemplate: _popupTemplate1
                };
              });
              lLayer.setInfoTemplates(finalInfoTemp);
            }
            if (layer.disableclientcaching) {
              lLayer.setDisableClientCaching(true);
            }
            lLayer.on('load', function (evt) {
              var removeLayers = [];
              array.forEach(evt.layer.visibleLayers, function (layer) {
                //remove any grouplayers
                if (evt.layer.layerInfos[layer].subLayerIds) {
                  removeLayers.push(layer);
                } else {
                  var _layerCheck = dojo.clone(layer);
                  while (evt.layer.layerInfos[_layerCheck].parentLayerId > -1) {
                    if (evt.layer.visibleLayers.indexOf(evt.layer.layerInfos[_layerCheck].parentLayerId) == -1) {
                      removeLayers.push(layer);
                    }
                    _layerCheck = dojo.clone(evt.layer.layerInfos[_layerCheck].parentLayerId);
                  }
                }
              });
              array.forEach(removeLayers, function (layerId) {
                evt.layer.visibleLayers.splice(evt.layer.visibleLayers.indexOf(layerId), 1);
              });
            });
            this._viewerMap.addLayer(lLayer);
            this._viewerMap.setInfoWindowOnClick(true);
          } else if (layer.type.toUpperCase() === 'FEATURE') {
            var _popupTemplate;
            if (layer.popup) {
              _popupTemplate = new PopupTemplate(layer.popup);
              lOptions.infoTemplate = _popupTemplate;
            }
            if (layer.hasOwnProperty('mode')) {
              var lmode;
              if (layer.mode === 'ondemand') {
                lmode = 1;
              } else if (layer.mode === 'snapshot') {
                lmode = 0;
              } else if (layer.mode === 'selection') {
                lmode = 2;
              }
              lOptions.mode = lmode;
            }
            lOptions.outFields = ['*'];
            if (layer.hasOwnProperty('autorefresh')) {
              lOptions.refreshInterval = layer.autorefresh;
            }
            if (layer.hasOwnProperty('showLabels')) {
              lOptions.showLabels = true;
            }
            lLayer = new FeatureLayer(layer.url, lOptions);
            lLayer.on('load', function (evt) {
              evt.layer.name = lOptions.id;
            });
            this._viewerMap.addLayer(lLayer);
            //-----------------------------------------------Apply Initial Filter-----------------------------------------------------
            filterLayer = lLayer;
            var defArr = [];
            if (defExp !== '') {
              defArr.push(defExp);
            }
                     
            lLayer.setDefinitionExpression(defArr.join(' AND '));
            //----Number of Features---------------
            lLayer.on('update-end', function (evt) {
              dom.byId('featcount').innerHTML = ' ' + evt.target.graphics.length;
            });
            //----------------
			
          } else if (layer.type.toUpperCase() === 'TILED') {
            if (layer.displayLevels) {
              lOptions.displayLevels = layer.displayLevels;
            }
            if (layer.hasOwnProperty('autorefresh')) {
              lOptions.refreshInterval = layer.autorefresh;
            }
            lLayer = new ArcGISTiledMapServiceLayer(layer.url, lOptions);
            if (layer.popup) {
              var finalInfoTemp2 = {};
              array.forEach(layer.popup.infoTemplates, function (_infoTemp) {
                var popupInfo = {};
                popupInfo.title = _infoTemp.title;
                if (_infoTemp.content) {
                  popupInfo.description = _infoTemp.content;
                } else {
                  popupInfo.description = null;
                }
                if (_infoTemp.fieldInfos) {
                  popupInfo.fieldInfos = _infoTemp.fieldInfos;
                }
                var _popupTemplate2 = new PopupTemplate(popupInfo);
                finalInfoTemp2[_infoTemp.layerId] = {
                  infoTemplate: _popupTemplate2
                };
              });
              lLayer.setInfoTemplates(finalInfoTemp2);
            }
            this._viewerMap.addLayer(lLayer);
          } else if (layer.type.toUpperCase() === 'BASEMAP') {
            var bmLayers = array.map(layer.layers.layer, function (bLayer) {
              var bmLayerObj = {
                url: bLayer.url,
                isReference: false
              };
              if (bLayer.displayLevels) {
                bmLayerObj.displayLevels = bLayer.displayLevels;
              }
              if (layer.hasOwnProperty('opacity')) {
                bmLayerObj.opacity = bLayer.opacity;
              }
              return new BasemapLayer(bmLayerObj);
            });
            var _newBasemap = new Basemap({
              id: 'defaultBasemap',
              title: layer.name,
              layers: bmLayers
            });
            var _basemapGallery = new BasemapGallery({
              showArcGISBasemaps: false,
              map: this._viewerMap
            }, '_tmpBasemapGallery');
            _basemapGallery.add(_newBasemap);
            _basemapGallery.select('defaultBasemap');
            _basemapGallery.destroy();
          }
        });
      }
    });
    return clazz;
  });
